#!/opt/cloudera/parcels/Anaconda/bin/python

"""
Panera standard utilities module.
"""

import re
import panUtils
from pyspark.sql import HiveContext
import datetime
from pyspark import SparkContext, SparkConf
from pyspark.sql.types import *
import panConfig




class panHdfs:

    """ 
    Class that can be used in pyspark scripts to manipulate HDFS operations on directories like
    
    Finding directories containing content
    Deleting and renameing directories.

    This class uses SparkContext to access the JVM FileSystem class

    USAGE:
    """

    def __init__ (self, sc):

      """
      Initialize using a SparkContext
      """

      self.URI           = sc._gateway.jvm.java.net.URI
      self.Path          = sc._gateway.jvm.org.apache.hadoop.fs.Path
      self.GlobFilter    = sc._gateway.jvm.org.apache.hadoop.fs.GlobFilter
      self.FileSystem    = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
      self.Configuration = sc._gateway.jvm.org.apache.hadoop.conf.Configuration

      self.fs = self.FileSystem.get(self.Configuration())

    def get_hdfs_dirs_w_success (self, rootPath):
    
        """
        Starting at rootPath in the HDFS directory structure, find all directories
        containing the file _SUCCESS.  The _SUCCESS file gets written by some
        processes to indicate that they are done writing all of their partitions.
        """
        dirs_w_data = []
        formattedRootPath = rootPath
        urlPrefix = 'hdfs://'
        if rootPath.lower().find(urlPrefix) == 0:
            formattedRootPath = rootPath[len(urlPrefix):]
            
        fileStatuses = self.fs.listStatus(self.Path(formattedRootPath))
        
        pathList = []
        for fileStatus in fileStatuses:
           pathList.append(fileStatus.getPath())
        
        for path in pathList:
           fileStatuses = self.fs.listStatus(path)
           for fileStatus in fileStatuses:
               if fileStatus.getPath().getName() == '_SUCCESS':
                   dirs_w_data.append ( "hdfs://" +  formattedRootPath + '/' + path.getName())
    
        return ",".join(dirs_w_data)
        
    def parse_hdfs_path (self, HDFSPath):
        parsedPath = HDFSPath
        urlPrefix = 'hdfs://'
        if HDFSPath.lower().find(urlPrefix) == 0:
            parsedPath = HDFSPath[len(urlPrefix):]
        return parsedPath
            

    def get_hdfs_subdirectories (self, rootPath):
    
        """
        Starting at rootPath in the HDFS directory structure, return a list of 
        all subdirectories.
        """
        retVal = []

        formattedRootPath = self.parse_hdfs_path(rootPath)

        fileStatuses = self.fs.listStatus(self.Path(formattedRootPath))
        
        for fileStatus in fileStatuses:
           retVal.append(formattedRootPath + '/' + fileStatus.getPath().getName())
        
        return retVal
 
    def dir_has_part_file (self, HDFSPath):
    
        retVal = False
        try:
            formattedHDFSPath = self.parse_hdfs_path(HDFSPath)
            fileStatuses = self.fs.listStatus(self.Path(formattedHDFSPath))
            for fileStatus in fileStatuses:
                if fileStatus.getPath().getName().find('part') == 0:
                    retVal = True
        except:
            pass
    
        return retVal
        
    def delete (self, HDFSPath):
    
        try:
            parsedPath = self.parse_hdfs_path(HDFSPath)
            return self.fs.delete(self.Path(parsedPath), True)
        except:
            return None
    
    def rename (self, fromPath, toPath):
    
        print "renaming %s to %s" % (fromPath, toPath)
        self.delete (toPath)
        parsedFromPath = self.parse_hdfs_path(fromPath)
        parsedToPath = self.parse_hdfs_path(toPath)
        return self.fs.rename (self.Path(parsedFromPath), self.Path(parsedToPath))

    def swap_directory_w_backup (self, fromPath, toPath):
        parsedFromPath = self.parse_hdfs_path(fromPath)
        parsedToPath = self.parse_hdfs_path(toPath)
        backupPath = parsedToPath + '_backup'
        self.rename(parsedToPath, backupPath)
        self.rename(parsedFromPath, parsedToPath)

    def get_modification_time (self, HDFSPath):
        fileModTime = None
        parsedPath = self.parse_hdfs_path(HDFSPath)
        baseName = parsedPath.split('/')[-1]
        fileStatuses = self.fs.listStatus(self.Path(parsedPath).getParent())
        for fileStatus in fileStatuses:
            fileName = fileStatus.getPath().getName()
            if fileName == baseName:
                fileModTS = fileStatus.getModificationTime()
                fileModTime = datetime.datetime.utcfromtimestamp(fileModTS / 1000.0)
                break
        return fileModTime

def sparkSetupPartition (hostImpala, dbName, tableName, targetDir, hiveContext, partitionName='business_date' ):

    """
    For hive/impala tables using the partitioning strategy of business_date=yyyy-mm-dd, point the partition to a directory and
    gather the statistics for it.

    USAGE:

        import panConfig
        import panSparkUtils
        from pyspark.sql import HiveContext

        theIni = panConfig.panConfig()
        edw_prefix = theIni.get ('edw_prefix', 'DATABASE')
        dbEDW = theIni.get ('dbEDW', 'DATABASE')
        hiveContext = HiveContext(sc)

        print panSparkUtils.sparkSetupPartition(hostImpala, dbName, tableName, targetDir, hiveContext)
    """
    retMsg = None

    # Extract the business_date from the targetDir
    subDir = targetDir.split('=')[-1]

    # Setup the drop and add partition commands
    dropSql = "alter table %s.%s drop if exists partition (%s = '%s')" % (dbName, tableName, partitionName, subDir)
    addSql = "alter table %s.%s add if not exists partition (%s = '%s') location '%s'" % (dbName, tableName, partitionName, subDir, targetDir)

    hiveContext.sql( dropSql ).collect()
    hiveContext.sql(addSql).collect()
    return panUtils.incrementalStats (hostImpala, dbName, tableName, targetDir, True)

def setupSparkTable (hostImpala, dbName, tableName, targetDir, hiveContext):

    """
    For non-partitioned hive/impala tables, drop and re-add the table using data underneath targetDir
    and gather the statistics for it.

    """
    retMsg = None

    # Setup the drop and add partition commands
    dropSql = "drop table %s.%s" % (dbName, tableName)
    addSql = "create external table %s.%s like parquet '%s/_metadata' stored as parquet location '%s'" % (dbName, tableName, targetDir, targetDir)

    hiveContext.sql( dropSql ).collect()
    hiveContext.sql(addSql).collect()
    # return panUtils.incrementalStats (hostImpala, dbName, tableName, targetDir, True)

def move_any_partitions (hostImpala, dbName, tableName, sourceDir, targetDir, sc, partitionName='business_date'):

   """
   For hive/impala tables using the partitioning strategy of business_date=yyyy-mm-dd, kill and fill data
   underneath targetDir with data underneath sourceDir then setup the partitions and gather statistics.

   USAGE:

      from pyspark import SparkContext, SparkConf
      from pyspark.streaming import StreamingContext
      from pyspark.sql import SQLContext
      import panUtils
      import panConfig
      
      conf = SparkConf().setAppName("Sample")
      sc = SparkContext(conf=conf)
      sqlContext = SQLContext(sc)
      
      theIni = panConfig.panConfig()
      
      hostImpala = theIni.get ('hostImpala')
      edw_prefix = theIni.get ('edw_prefix', 'DATABASE')
      dbEDW = theIni.get ('dbEDW', 'DATABASE')
      urban_air_tmp_prefix = theIni.get("urban_air_tmp_prefix", "TMP")
      
      dbName = dbEDW
      tableName = 'ua_sends'
      sourceDir = urban_air_tmp_prefix + '/' + tableName
      targetDir = edw_prefix + '/' + tableName
      
      # will default to  partition name to business_date
      panUtils.move_any_partitions(hostImpala, dbName, tableName, sourceDir, targetDir, sc)
   
   """

   # Get a FileSystem and HiveContext object from the SparkContext.  This is faster for HDFS operations than wrapping "hadoop fs" OS commands.
   theFs = panHdfs(sc)
   hiveContext = HiveContext(sc)
   pattern='^.+/%s=.*$' % (partitionName)

   # iterate through all subdirectories of sourceDir
   for sourceSubDir in theFs.get_hdfs_subdirectories (sourceDir):
       # If directory ends with /business_date=YYYY-MM-DD, then build up targetDirDate,
       # rename the file, and make impala calls to point the business date partition to
       # the directory with the new data.
       if re.match( pattern, sourceSubDir):
           businessDateSuffix = sourceSubDir.split('/')[-1]
           targetDirDate = targetDir + '/' + businessDateSuffix
           theFs.rename (sourceSubDir, targetDirDate)
           sparkSetupPartition (hostImpala, dbName, tableName, targetDirDate, hiveContext, partitionName)

def move_business_date_partitions (hostImpala, dbName, tableName, sourceDir, targetDir, sc):
   return move_any_partitions (hostImpala, dbName, tableName, sourceDir, targetDir, sc )



def move_non_partitioned_table (hostImpala, dbName, tableName, sourceDir, targetDir, sc):

   """
   For hive/impala tables not using a partitioning strategy, kill and fill data
   underneath targetDir with data underneath sourceDir then and gather statistics.
   
   """

   # Get a FileSystem and HiveContext object from the SparkContext.  This is faster for HDFS operations than wrapping "hadoop fs" OS commands.
   theFs = panHdfs(sc)
   hiveContext = HiveContext(sc)

   theFs.rename (sourceDir, targetDir)

   setupSparkTable (hostImpala, dbName, tableName, targetDir, hiveContext)

def pan_conf_level ( name, memory='VLow',  priority='Low', display=0, vCores=1 ):

   """
      pan_conf_level returns a SparkConf() with the memory per executor set based on memory level passed in
      If you know what you need or want to change in just a bit you can pass in a number of meg so 1048
      would give you 1048m or 1g.
      the memory
      VLow, Low, STD, High, Star or a number are valid options for memory.
      1.5g,  5g,  9g,  16g, 24g are the memory value that go with the memory levels

      the priority of your job will be used to calculate how many maximum allocated executor/containers
      your job will take.
      VLow, Low, STD, High, Star are Valid options for priority
      10%,  20%, 33%,  %50,  80%

      display will include the memory on the app name as well as print.
      
      vCore the number of vCores per executor.  Can be 'Max' or 'Avg'
         to set to a value that will use as many as posable with out
         using more that Priority % of the systems vcores

      priority of 'VLow'
         at lest 10 simultaneously jobs running at this level
      priority of 'Low'
         at lest 5 simultaneously jobs running at this level
      priority of 'STD'
         at lest 3 simultaneously jobs running at this level
      priority of 'High'
         at lest 2 simultaneously jobs running at this level
         or 1 at this level and 2 Low level jobs
      priority of 'Star':
         at lest 1 simultaneously job running at this level
         and 1 at Low level

   """


   #max_cores = 240
   #max_memory = 1363148
   theConfig = panConfig.panConfig()
   max_cores = int(theConfig.get ('priority_max_cores', 'PRIORITY'))
   max_memory = int ( theConfig.get ('priority_max_memory', 'PRIORITY'))
   if priority.lower() == 'low':
      priority = 'Low'
      maxSys = 0.2
   elif  priority.lower() == 'std' or priority.lower() == 'standerd':
      priority = 'STD'
      maxSys = 0.33
   elif  priority.lower() == 'high':
      priority == 'high'
      maxSys = 0.5
   elif  priority.lower() == 'star':
      priority == 'Star'
      maxSys = 0.66
   elif  priority.lower() == 'vip':
      priority == 'VIP'
      maxSys = 0.8
   else:
      maxSys = 0.1
      priority = 'VLow'

   
   if isinstance(memory, int):
      mem_per = memory
      memory = 'cust'
   elif memory.lower() ==  'low':
      mem_per = 5120
   elif memory.lower() ==  'std':
      mem_per = 9216
   elif memory.lower() ==  'high':
      mem_per = 16384
   elif memory.lower() ==  'star':
      mem_per = 24576
   else:
      mem_per = 1536

   if len(str(mem_per)) > 4:
      set_per = "%dg" % int(mem_per/1024)
   else:
      set_per = "%dm" % mem_per

   over_head_m = int(0.12*max_memory)
   max_memory = max_memory - over_head_m

   max_exe = int((maxSys * max_memory) / mem_per)

   if not isinstance(vCores, int):
      if vCores == 'Max':
         vCores = int ( max_cores * maxSys / max_exe )
         if vCores < 0:
            vCores = 1
      elif vCores == 'Avg':
         vCores = int(( 2 + int ( max_cores * maxSys / max_exe ) ) / 2)
      else:
         vCores = 1

      
   if int(vCores * max_exe) > int(maxSys*max_cores):
      max_exe = int(maxSys*max_cores/vCores)
   if max_exe < 1:
      max_exe = 1
   if max_exe > max_cores:
      max_exe = max_cores
      vCores = 1

   if display != 0:
      appName = "%s_%s m:%s" % (priority, name, set_per )
   else:
      appName = "%s_%s" % (priority, name )

   theConf = SparkConf().setAppName(appName)\
       .set('spark.dynamicAllocation.maxExecutors',max_exe)\
       .set('spark.executor.memory',set_per)\
       .set('spark.executor.cores',vCores)

   if display!=0:
      print "spark.app.name %s " % appName
      print "spark.executor.memory %s " % set_per
      print "spark.executor.cores %d " % vCores
      print "spark.dynamicAllocation.maxExecutors %d " % max_exe

   return theConf

def genCreateTableSql( theSchema, dbEDW, tableName, targetDir, partitionCol="None" ):
   """
      genCreateTableSql will return a string that you can run from a hive sesstion
      theSchema should be a  StructType([]) with each row of  StructField()
      only StructField of StringType, IntegerType, LongType, DoubleType, FloatType,
      ShortType, TimestampType, ByteType, and BooleanType
        are suported by this utility but other more complex types are valid.
   """
   pat1Str = """
   create external table IF NOT EXISTS %s.%s (
   """ %( dbEDW, tableName )

   pat2StrA = """)
   partitioned by (%s string)
   stored as parquet location'%s'
   """ % (partitionCol, targetDir)

   pat2StrB = """)
   stored as parquet location'%s'
   """ % (targetDir)

   pat3Str = """
   %s  %s %s """

   sList = [f for f in theSchema.fields]
   rtnStr = pat1Str
   nextStr = ''
   for line in sList:
      if partitionCol == 'None' or line.name != partitionCol:
         if isinstance(line.dataType, StringType):
            rtnStr += pat3Str % (nextStr, line.name, 'STRING')
         elif isinstance(line.dataType, IntegerType):
            rtnStr += pat3Str % (nextStr, line.name, 'INT')
         elif isinstance(line.dataType, LongType):
            rtnStr += pat3Str % (nextStr, line.name, 'BIGINT')
         elif isinstance(line.dataType, DoubleType):
            rtnStr += pat3Str % (nextStr, line.name, 'DOUBLE')
         elif isinstance(line.dataType, FloatType):
            rtnStr += pat3Str % (nextStr, line.name, 'FLOAT')
         elif isinstance(line.dataType, ShortType):
            rtnStr += pat3Str % (nextStr, line.name, 'SMALLINT')
         elif isinstance(line.dataType, TimestampType):
            rtnStr += pat3Str % (nextStr, line.name, 'TIMESTAMP')
         elif isinstance(line.dataType, ByteType):
            rtnStr += pat3Str % (nextStr, line.name, 'TINYINT')
         elif isinstance(line.dataType, BooleanType):
            rtnStr += pat3Str % (nextStr, line.name, 'BOOLEAN')
         else:
            errStr =  "not suported type on column name %s type %s " % ( line.name, line.dataType )
            print errStr
            raise TypeError(errStr)
         nextStr = ','
   if partitionCol == 'None':
      rtnStr += pat2StrB
   else:
      rtnStr += pat2StrA
   return rtnStr

def genCreateTableBusinessDateSql( theSchema, dbEDW, tableName, targetDir ):
   partitionCol='business_date'
   rtnStr = genCreateTableSql( theSchema, dbEDW, tableName, targetDir, partitionCol )
   return rtnStr

