

theDict = {'A' : 'c', 'B' : 'b', 'C' : 'a'}


print theDict.keys()

print theDict.values()
