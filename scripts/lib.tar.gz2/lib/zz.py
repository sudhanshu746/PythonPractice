def _filter_on_dim ( v_filtered, stage, broadcast_values):

    retVal = []

    dimAttribute = stage['dimAttribute']
    dimTableName = stage['dimTableName']
    joinColumns = eval(stage['joinColumns'])
    attributeValues = eval(stage['attributeValues'])
    inNotInFlag = stage['inNotInFlag']
    dim_dictionary = broadcast_values['dimensions'][dimTableName]


    
    for listRec in v_filtered:
        keyList = []
        for joinColumn in joinColumns:
            keyList.append(getLongByKey (listRec, joinColumn))

        dimKey = _list_to_tuple (keyList)
      
        if dimKey in dim_dictionary:
            dimAttrValue = dim_dictionary[dimKey][dimAttribute]
            if dimAttrValue in attributeValues and inNotInFlag == 1:
                retVal.append(listRec)
            elif dimAttrValue not in attributeValues and inNotInFlag == 0:
                retVal.append(listRec)

    return retVal

