#!/opt/cloudera/parcels/Anaconda/bin/python

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import os

import panConfig



def send_message (hostSMTP, toEmail, fromEmail, subject, body, attachmentFilenames = []):

    """
    Utility function for sending emails.

    toEmail should be a list of recipients

    attachmentFilenames is an optional list of filenames to attach to the mail message.  These
    should be fully qualified paths on the local filesystem.

    """

    print "in send_message"
    theSMTP = smtplib.SMTP(hostSMTP)
    theSMTP.ehlo()
    theSMTP.starttls()

    # Setup the message with subject, from, and to
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['To'] = ", ".join(toEmail)
    msg['From'] = fromEmail

    # Add each of the attachments
    for attachmentFilename in attachmentFilenames:
        attachmentFile = file(attachmentFilename)
        attachment = MIMEText(attachmentFile.read())
        attachmentBasename = os.path.basename(attachmentFilename)
        attachment.add_header('Content-Disposition', 'attachment', filename=attachmentBasename)
        msg.attach(attachment)

    # Add in the body of the e-mail
    content = MIMEText(body, 'plain')
    msg.attach(content)

    # Send the e-mail
    theSMTP.sendmail(fromEmail, toEmail, msg.as_string())

