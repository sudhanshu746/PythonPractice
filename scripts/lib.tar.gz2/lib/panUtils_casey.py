#!/opt/cloudera/parcels/Anaconda/bin/python

"""
Panera standard utilities module.
"""

import shlex
import subprocess
import re
from impala.dbapi import connect





def wrap_os_cmd (cmd):

    # cmd is an os level command to run.  This function will run cmd and return a tupple of
    # (returnCode, stdOutput, stdError)
    # The caller can interpret these values as desired.

    # The shlex.split method will create an argument list suitable for passing to subprocess.Popen
    cmdArgs = shlex.split (cmd)


    # Setup subprocess.Popen so that we can access standard out and error and put the results
    # into a string for each one
    thePipe = subprocess.Popen (cmdArgs, stdout=subprocess.PIPE,  stderr=subprocess.PIPE)

    # The communicate method will write standard out and error to outputText variable
    outputText = thePipe.communicate()

    # Get the return code
    returnCode = thePipe.returncode

    # Return tuple of returnCode, stdOutput, stdError
    return ( returnCode, outputText[0], outputText[1])


def cleanup_obsolete_directories (targetDir,keepDays=1):

    # Given a targetDir, clean up all directories at the same level as they are obsolete.
    #print keepDays

    # On success we will return None
    retMsg = None

    # Issue a hadoop ls command for one directory level above targetDir to see if there are more directories
    # than the target.
    obsoleteDirectories = []
    baseDir = re.sub ( r'/[^/]*$', '', targetDir)
    lsCmd = "/usr/bin/hadoop fs -ls -t %s" % baseDir
    returnCode, stdOutput, stdError = wrap_os_cmd(lsCmd)

    fileCnt = 0
    # Find the obsolete directories in the hadoop ls output always keeping the previous partition for rollback
    if returnCode == 0:
        for outLine in stdOutput.split('\n'):
            if outLine.find(baseDir) >= 0:
                dirName = outLine.split(" ")[-1]
                if dirName != targetDir and fileCnt >= int(keepDays):
                    obsoleteDirectories.append(dirName)
                fileCnt += 1
    else:
        retMsg = "ERROR -> DIRECTORY CLEANUP: %s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (targetDir, stdError)
        return retMsg

    # If we found any obsolete directories than issue a hadoop rm -r command
    if len(obsoleteDirectories) > 0:
        cleanupCmd = "/usr/bin/hadoop fs -rm -r -skipTrash " + " ".join (obsoleteDirectories)
        returnCode, stdOutput, stdError = wrap_os_cmd (cleanupCmd)
        if returnCode != 0:
            retMsg = "ERROR -> DIRECTORY CLEANUP: %s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (targetDir, stdError)
            return retMsg

    retMsg = "SUCCESS -> DIRECTORY CLEANUP: %s" % (targetDir)
    return retMsg


def setup_business_date_partition (hostImpala, dbName, tableName, targetDir):

    """
    For hive/impala tables using the partitioning strategy of business_date=yyyy-mm-dd, point the partition to a directory and 
    gather the statistics for it.

    USAGE:

        import panConfig
        import panUtils
        theIni = panConfig.panConfig()
        hostImpala = theIni.get ('hostImpala')
        edw_prefix = theIni.get ('edw_prefix', 'DATABASE')
        dbEDW = theIni.get ('dbEDW', 'DATABASE')
        print panUtils.setup_business_date_partition (hostImpala, dbName, tableName, targetDir)
    """
    retMsg = None

    # Extract the business_date from the targetDir
    business_date = targetDir.split('=')[-1]

    # Create the partition if it does not exist and assign its location to targetDir in one step
    partition_create_cmd = """hive -e "ALTER TABLE %s.%s ADD IF NOT EXISTS PARTITION( business_date = '%s' ) LOCATION '%s'" """ % (dbName, tableName, business_date, targetDir)
    returnCode, stdOutput, stdError = wrap_os_cmd (partition_create_cmd)
    if returnCode != 0:
        retMsg = "ERROR -> CREATING PARTITION: %s.%s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (dbName, tableName, stdError)
        return retMsg

    # assign the partition's location to targetDir
    partition_location_cmd = """hive -e "use %s; ALTER TABLE %s.%s PARTITION( business_date = '%s' ) SET LOCATION '%s'" """ % (dbName, dbName, tableName, business_date, targetDir)
    returnCode, stdOutput, stdError = wrap_os_cmd (partition_location_cmd)
    if returnCode != 0:
        retMsg = "ERROR -> ASSIGNING PARTITION: %s.%s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (dbName, tableName, stdError)
        return retMsg

    return incrementalStats (hostImpala, dbName, tableName, targetDir, True)



def swap_location (dbName, tableName, targetDir, partFlag):

    #print targetDir

    retMsg = None

    if partFlag:
        # Extract the year, month, and day from the end of targetDir
        yyyymmdd = targetDir.split('/')[-2]

        # Create the partition if it does not exist and assign its location to targetDir in one step
        partition_create_cmd = """hive -e "ALTER TABLE %s.%s ADD IF NOT EXISTS PARTITION( business_date = '%s' ) LOCATION '%s'" """ % (dbName, tableName, yyyymmdd, targetDir)
        #print partition_create_cmd

        returnCode, stdOutput, stdError = wrap_os_cmd (partition_create_cmd)

        if returnCode != 0:
            retMsg = "ERROR -> CREATING PARTITION: %s.%s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (dbName, tableName, stdError)
            return retMsg

        # assign the partition's location to targetDir
        partition_location_cmd = """hive -e "use %s; ALTER TABLE %s.%s PARTITION( business_date = '%s' ) SET LOCATION '%s'" """ % (dbName, dbName, tableName, yyyymmdd, targetDir)
        #print partition_location_cmd

        returnCode, stdOutput, stdError = wrap_os_cmd (partition_location_cmd)

        if returnCode != 0:
            retMsg = "ERROR -> ASSIGNING PARTITION: %s.%s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (dbName, tableName, stdError)

        #print retMsg

        return retMsg

    else:
        # assign the partition's location to targetDir
        partition_location_cmd = """hive -e "ALTER TABLE %s.%s SET LOCATION '%s'" """ % (dbName, tableName, targetDir)

        returnCode, stdOutput, stdError = wrap_os_cmd (partition_location_cmd)

        if returnCode != 0:
            retMsg = "ERROR -> ASSIGNING PARTITION: %s.%s\nBegin Error Detail========\n%s\nEnd Error Detail========" % (dbName, tableName, stdError)
        else:
            retMsg = "SUCCESS -> ASSIGNING PARTITION: %s.%s" % (dbName, tableName)

        return retMsg


def incrementalStats (hostImpala, dbName, tableName, targetDir, partFlag):

    yyyymmdd = ""

    # Uses impala to compute incremental statistics on a table
    try:
       conn = connect(host=hostImpala)
       cursor = conn.cursor()

       # Force impala to reload its metadata cache for tableName.  Otherwise, it may not know about the table
       cursor.execute( 'INVALIDATE METADATA %s.%s' % (dbName, tableName) )

       if partFlag:
           # Extract the year, month, and day from the end of targetDir
           yyyymmdd = targetDir.split('/')[-2:-1][0]
           if re.match (r'^.*/business_date=\d{4}-\d{2}-\d{2}', targetDir):
               yyyymmdd = targetDir.split('=')[-1]

           # Compute stats on just the current partition
           cursor.execute( "COMPUTE INCREMENTAL STATS %s.%s PARTITION (business_date = '%s')" % (dbName, tableName, yyyymmdd))

       else:
           cursor.execute( 'COMPUTE STATS %s.%s' % (dbName, tableName) )

       # Cleanup
       cursor.close()
       conn.close()

       return "SUCCESS -> Computed stats on %s.%s Partition: %s" % (dbName, tableName, yyyymmdd)

    except:
       return "ERROR -> Exception computing stats on %s.%s Partition: %s" % (dbName, tableName, yyyymmdd)



def invalidateMetadata (hostImpala, dbName, tableName):
    # Uses impala to compute incremental statistics on a table
    try:
       conn = connect(host=hostImpala)
       cursor = conn.cursor()
       # Force impala to reload its metadata cache for tableName.  Otherwise, it may not know about the table
       cursor.execute( 'INVALIDATE METADATA %s.%s' % (dbName, tableName) )
       # Cleanup
       cursor.close()
       conn.close()
       return "SUCCESS -> INVALIDATE METADATA %s.%s" % (dbName, tableName)
    except:
       return "ERROR -> Exception INVALIDATE METADATA %s.%s " % (dbName, tableName)

def create_directory ( targetDir ):
    # On success we will return None
    retMsg = None

    mkdirCmd = "/usr/bin/hadoop fs -mkdir %s" % targetDir
    returnCode, stdOutput, stdError = wrap_os_cmd(mkdirCmd)

    # Find the obsolete directories in the hadoop ls output always keeping the previous partition for rollback
    if returnCode != 0:
       testStr = stdError[-14:]
       if testStr[0:13] != ": File exists":
          retMsg = "ERROR -> CREATE DIRECTORY: %s\nBegin Error Detail========\n%s\nEnd Error Detail========" % ( targetDir, stdError)
    return retMsg
