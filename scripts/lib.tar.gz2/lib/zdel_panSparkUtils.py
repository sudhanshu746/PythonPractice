#!/opt/cloudera/parcels/Anaconda/bin/python

##
## 11/13/2017.  Kept copy of this when synchronizing the prod area of the Century link cluster with production.  This version of panSparkUtils had
##              a couple of unused functions.  If these are not needed after a few weeks, this file can be deleted.


"""
Panera standard utilities module.
"""

import re
import panUtils
from pyspark.sql import HiveContext
import datetime




class panHdfs:

    """ 
    Class that can be used in pyspark scripts to manipulate HDFS operations on directories like
    
    Finding directories containing content
    Deleting and renameing directories.

    This class uses SparkContext to access the JVM FileSystem class

    USAGE:
    """

    def __init__ (self, sc):

      """
      Initialize using a SparkContext
      """

      self.URI           = sc._gateway.jvm.java.net.URI
      self.Path          = sc._gateway.jvm.org.apache.hadoop.fs.Path
      self.GlobFilter    = sc._gateway.jvm.org.apache.hadoop.fs.GlobFilter
      self.FileSystem    = sc._gateway.jvm.org.apache.hadoop.fs.FileSystem
      self.Configuration = sc._gateway.jvm.org.apache.hadoop.conf.Configuration

      self.fs = self.FileSystem.get(self.Configuration())

    def get_hdfs_dirs_w_success (self, rootPath):
    
        """
        Starting at rootPath in the HDFS directory structure, find all directories
        containing the file _SUCCESS.  The _SUCCESS file gets written by some
        processes to indicate that they are done writing all of their partitions.
        """
        dirs_w_data = []
        formattedRootPath = rootPath
        urlPrefix = 'hdfs://'
        if rootPath.lower().find(urlPrefix) == 0:
            formattedRootPath = rootPath[len(urlPrefix):]
            
        fileStatuses = self.fs.listStatus(self.Path(formattedRootPath))
        
        pathList = []
        for fileStatus in fileStatuses:
           pathList.append(fileStatus.getPath())
        
        for path in pathList:
           fileStatuses = self.fs.listStatus(path)
           for fileStatus in fileStatuses:
               if fileStatus.getPath().getName() == '_SUCCESS':
                   dirs_w_data.append ( "hdfs://" +  formattedRootPath + '/' + path.getName())
    
        return ",".join(dirs_w_data)
        
    def parse_hdfs_path (self, HDFSPath):
        parsedPath = HDFSPath
        urlPrefix = 'hdfs://'
        if HDFSPath.lower().find(urlPrefix) == 0:
            parsedPath = HDFSPath[len(urlPrefix):]
        return parsedPath
            

    def get_hdfs_subdirectories (self, rootPath):
    
        """
        Starting at rootPath in the HDFS directory structure, return a list of 
        all subdirectories.
        """
        retVal = []

        formattedRootPath = self.parse_hdfs_path(rootPath)

        fileStatuses = self.fs.listStatus(self.Path(formattedRootPath))
        
        for fileStatus in fileStatuses:
           retVal.append(formattedRootPath + '/' + fileStatus.getPath().getName())
        
        return retVal
 
    def dir_has_part_file (self, HDFSPath):
    
        retVal = False
        try:
            formattedHDFSPath = self.parse_hdfs_path(HDFSPath)
            fileStatuses = self.fs.listStatus(self.Path(formattedHDFSPath))
            for fileStatus in fileStatuses:
                if fileStatus.getPath().getName().find('part') == 0:
                    retVal = True
        except:
            pass
    
        return retVal
        
    def delete (self, HDFSPath):
    
        try:
            parsedPath = self.parse_hdfs_path(HDFSPath)
            return self.fs.delete(self.Path(parsedPath), True)
        except:
            return None
    
    def rename (self, fromPath, toPath):
    
        print "renaming %s to %s" % (fromPath, toPath)
        self.delete (toPath)
        parsedFromPath = self.parse_hdfs_path(fromPath)
        parsedToPath = self.parse_hdfs_path(toPath)
        return self.fs.rename (self.Path(parsedFromPath), self.Path(parsedToPath))

    def swap_directory_w_backup (self, fromPath, toPath):
        parsedFromPath = self.parse_hdfs_path(fromPath)
        parsedToPath = self.parse_hdfs_path(toPath)
        backupPath = parsedToPath + '_backup'
        self.rename(parsedToPath, backupPath)
        self.rename(parsedFromPath, parsedToPath)

    def get_modification_time (self, HDFSPath):
        fileModTime = None
        parsedPath = self.parse_hdfs_path(HDFSPath)
        baseName = parsedPath.split('/')[-1]
        fileStatuses = self.fs.listStatus(self.Path(parsedPath).getParent())
        for fileStatus in fileStatuses:
            fileName = fileStatus.getPath().getName()
            if fileName == baseName:
                fileModTS = fileStatus.getModificationTime()
                fileModTime = datetime.datetime.utcfromtimestamp(fileModTS / 1000.0)
                break
        return fileModTime


def sparkSetupPartition (hostImpala, dbName, tableName, targetDir, hiveContext):

    """
    For hive/impala tables using the partitioning strategy of business_date=yyyy-mm-dd, point the partition to a directory and 
    gather the statistics for it.

    USAGE:

        import panConfig
        import panSparkUtils
        theIni = panConfig.panConfig()
        edw_prefix = theIni.get ('edw_prefix', 'DATABASE')
        dbEDW = theIni.get ('dbEDW', 'DATABASE')
        print panSparkUtils.setup_business_date_partition (dbName, tableName, targetDir)
    """
    retMsg = None

    # Extract the business_date from the targetDir
    business_date = targetDir.split('=')[-1]

    # Setup the drop and add partition commands
    dropSql = "alter table %s.%s drop if exists partition (business_date = '%s')" % (dbName, tableName, business_date)
    addSql = "alter table %s.%s add if not exists partition (business_date = '%s') location '%s'" % (dbName, tableName, business_date, targetDir)

    hiveContext.sql( dropSql ).collect()
    hiveContext.sql(addSql).collect()
    return panUtils.incrementalStats (hostImpala, dbName, tableName, targetDir, True)



def setupSparkTable (hostImpala, dbName, tableName, targetDir, hiveContext):

    """
    For non-partitioned hive/impala tables, drop and re-add the table using data underneath targetDir
    and gather the statistics for it.

    """
    retMsg = None

    # Setup the drop and add partition commands
    dropSql = "drop table %s.%s" % (dbName, tableName)
    addSql = "create external table %s.%s like parquet '%s/_metadata' stored as parquet location '%s'" % (dbName, tableName, targetDir, targetDir)

    print dropSql
    print addSql

    hiveContext.sql( dropSql ).collect()
    hiveContext.sql(addSql).collect()
    # return panUtils.incrementalStats (hostImpala, dbName, tableName, targetDir, True)




def move_business_date_partitions (hostImpala, dbName, tableName, sourceDir, targetDir, sc):

   """
   For hive/impala tables using the partitioning strategy of business_date=yyyy-mm-dd, kill and fill data
   underneath targetDir with data underneath sourceDir then setup the partitions and gather statistics.

   USAGE:

      from pyspark import SparkContext, SparkConf
      from pyspark.streaming import StreamingContext
      from pyspark.sql import SQLContext
      import panUtils
      import panConfig
      
      conf = SparkConf().setAppName("Sample")
      sc = SparkContext(conf=conf)
      sqlContext = SQLContext(sc)
      
      theIni = panConfig.panConfig()
      
      hostImpala = theIni.get ('hostImpala')
      edw_prefix = theIni.get ('edw_prefix', 'DATABASE')
      dbEDW = theIni.get ('dbEDW', 'DATABASE')
      urban_air_tmp_prefix = theIni.get("urban_air_tmp_prefix", "TMP")
      
      dbName = dbEDW
      tableName = 'ua_sends'
      sourceDir = urban_air_tmp_prefix + '/' + tableName
      targetDir = edw_prefix + '/' + tableName
      
      panUtils.move_business_date_partitions(hostImpala, dbName, tableName, sourceDir, targetDir, sc)
   
   """

   # Get a FileSystem and HiveContext object from the SparkContext.  This is faster for HDFS operations than wrapping "hadoop fs" OS commands.
   theFs = panHdfs(sc)
   hiveContext = HiveContext(sc)


   # iterate through all subdirectories of sourceDir
   for sourceDir in theFs.get_hdfs_subdirectories (sourceDir):

       # If directory ends with /business_date=YYYY-MM-DD, then build up targetDirDate,
       # rename the file, and make impala calls to point the business date partition to
       # the directory with the new data.
       if re.match( r'^.+/business_date=\d{4}-\d{2}-\d{2}$', sourceDir):
           businessDateSuffix = sourceDir.split('/')[-1]
           targetDirDate = targetDir + '/' + businessDateSuffix
           theFs.rename (sourceDir, targetDirDate)
           sparkSetupPartition (hostImpala, dbName, tableName, targetDirDate, hiveContext)






def move_non_partitioned_table (hostImpala, dbName, tableName, sourceDir, targetDir, sc):

   """
   For hive/impala tables not using a partitioning strategy, kill and fill data
   underneath targetDir with data underneath sourceDir then and gather statistics.
   
   """

   # Get a FileSystem and HiveContext object from the SparkContext.  This is faster for HDFS operations than wrapping "hadoop fs" OS commands.
   theFs = panHdfs(sc)
   hiveContext = HiveContext(sc)

   theFs.rename (sourceDir, targetDir)

   setupSparkTable (hostImpala, dbName, tableName, targetDir, hiveContext)

